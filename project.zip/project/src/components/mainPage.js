import React, { Component } from 'react';

export default class MainPage extends Component {
    constructor(props){
    super(props);
    this.state = {
      userData: "",
    };
}
    componentDidMount(){
        fetch("http://localhost:5000/userdata",{
    method: "post",
    crossDomain:true,
    headers:{
      "Content-type":"application/json",
      Accept:"application/json",
      "Access-Control-Allow-Origin":"*",
    },
    body:JSON.stringify({
        token: window.localStorage.getItem("token"), 
    }),
    })
    .then((res) => res.json())
    .then((data) => {
      console.log(data, "userdata");
      this.setState({userData: data.data});
      if(data.data == "Token Expired"){
        alert("Your Token Has Expired Please Try Logging In Again")
        window.localStorage.clear();
        window.location.href = "./sign-in";
      }
    });
    }
    logOut = () =>{
        window.localStorage.clear();
        window.location.href = "./sign-in";
    }
    toDoButton = () =>{
      window.location.href = "./toDoList";
    }
    render(){
        return(
            <div>
                <button onClick={this.logOut} className='button'>Log Out</button>
                <br />
                <br />
                <h3>Main Menu Page</h3>
                <br />
                <br />
                <label>Hello {this.state.userData.fname} {this.state.userData.lname} 
                please click one of the button below to take you to the correct page or 
                if you wish you can click the logout button to take you back to the sign 
                in page.</label>
                <br />
                <br />
                <div className="d-grid">
                  <br />
                  <button onClick={this.toDoButton} className='button'>
                    To-Do List</button>
                 </div>    
            </div>
        );
    }
}