import React, { Component } from 'react';

export default class ToDoList extends Component {
    constructor(props){
    super(props);
    this.state = {
      userData: "",
    };
    }
    componentDidMount(){
        fetch("http://localhost:5000/userdata",{
    method: "post",
    crossDomain:true,
    headers:{
      "Content-type":"application/json",
      Accept:"application/json",
      "Access-Control-Allow-Origin":"*",
    },
    body:JSON.stringify({
        token: window.localStorage.getItem("token"), 
    }),
    })
    .then((res) => res.json())
    .then((data) => {
      console.log(data, "userdata");
      this.setState({userData: data.data});
      if(data.data == "Token Expired"){
        alert("Your Token Has Expired Please Try Logging In Again")
        window.localStorage.clear();
        window.location.href = "./sign-in";
      }
    });
    };
    logOut = () =>{
    window.localStorage.clear();
    window.location.href = "./sign-in";
    };
    backButton = () =>{
        window.location.href = "./mainPage";
    };
    render(){
            return(
            <div>
                <button onClick = {this.logOut} className='button'>Log Out</button>    <button onClick = {this.backButton}className='button'>Back</button>
                <br />
                <br />
                <h3>To-Do List Page</h3>
                <div>
                <form>
                    <input className='todo-input' placeholder='What item would you like add?'/>
                    <button className='button' type='submit'>Add Item</button>
                </form>
                </div>
            </div>
        );
    };
}
